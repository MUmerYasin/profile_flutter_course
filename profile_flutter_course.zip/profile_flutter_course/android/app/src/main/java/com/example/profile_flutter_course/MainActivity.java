package com.example.profile_flutter_course;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
