
import 'dart:ui';

// const Color appBackgroundColor = Color(0xffffffff);
const Color appBarColorCustom = Color(0xff5c5258);
const Color greenIconColorCustom = Color(0xff0c590b);
const Color subTitleColorCustom = Color(0xffa7a7a7);
const Color logoutIconColorCustom = Color(0xffaf2d27);
const Color bottomNavigationBarColorCustom = Color(0xff969696);
