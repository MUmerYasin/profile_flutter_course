
const String logOutString = "Logout";

///user profile data
///user name > Email
const String userNameString = "Abbas Aslam";
const String userEmailString = "example123@gmail.com";

///Profile Screen Tab List text
const String firstTabListString = "Posts";
const String secondTabListString = "Polling";
const String thirdTabListString = "Groups";
const String fourthTabListString = "Profile";

///Profile Screen List Tile Data
const String firstListTileString = "Languages";
const String secondListTileString = "App Theme";
const String thirdListTileString = "Change Password";
const String fourthListTileString = "Terms And Conditions";
const String fiveListTileString = "Rate This App";
const String sixListTileString = "About Us";

///Profile Screen bottom Navigation Bar text
const String firstBottomNavigationBarString = "Home";
const String secondBottomNavigationBarString = "Polling";
const String thirdBottomNavigationBarString = "Group";
const String fourthBottomNavigationBarString = "Profile";

