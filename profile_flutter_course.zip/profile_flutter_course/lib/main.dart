import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:profile_flutter_course/Configs/ProjectColors/project_colors.dart';
import 'package:profile_flutter_course/Configs/ProjectStrings/project_strings.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'selection',
      theme: ThemeData(
        primarySwatch: Colors.grey,
        textTheme: GoogleFonts.playfairDisplayTextTheme(
          Theme.of(context).textTheme,
        ),
      ),
      home: const MyHomePage(title: 'PROFILE'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          style: GoogleFonts.playfairDisplay(
            textStyle: const TextStyle(
              color: appBarColorCustom,
            ),
          ),
        ),
        elevation: 1.0,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: DefaultTabController(
          length: 4,
          initialIndex: 1,

          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              /// Logout Button
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  TextButton.icon(
                    icon: const Icon(
                      Icons.logout,
                      color: Colors.red,
                    ),
                    label: const Text(logOutString),
                    onPressed: () {},
                  ),
                ],
              ),

              /// Profile Picture, User Name, Email
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 50.0,
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: greenIconColorCustom,
                          width: 2,
                        ),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(10.0)),
                      ),
                      child: ClipRRect(
                        child: Image.asset('lib/assets/images/222.png'),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ),

                  const Padding(
                    padding: EdgeInsets.all(12.0),
                    child: Text(
                      userNameString,
                      style: TextStyle(
                        color: greenIconColorCustom,
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const Text(
                    userEmailString,
                    style: TextStyle(
                      color: subTitleColorCustom,
                      fontSize: 12.0,
                    ),
                  ),
                ],
              ),

              /// Tab Bar
              Row(
                mainAxisSize : MainAxisSize.min,
                children: const [
                  Flexible(
                    fit: FlexFit.loose,

                  child: SizedBox(
                      height: 300.0,
                      // width: MediaQuery.of(context).size.width,
                      width: double.infinity,

                      child: TabBar(
                          isScrollable: true,

                        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics(),),
                        tabs: <Widget>[
                          Tab(
                            icon: Icon(Icons.cloud_outlined),
                          ),
                          Tab(
                            icon: Icon(Icons.beach_access_sharp),
                          ),
                          Tab(
                            icon: Icon(Icons.brightness_5_sharp),
                          ),
                          Tab(
                            icon: Icon(Icons.brightness_5_sharp),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),

              // Expanded(child: SizedBox(
              //   height: 300.0,
              //   width: MediaQuery.of(context).size.width,
              //   child: const TabBarView(
              //     children: <Widget>[
              //
              //       Center(
              //         child: Text("It's cloudy here"),
              //       ),
              //       Center(
              //         child: Text("It's cloudy here"),
              //       ),
              //       Center(
              //         child: Text("It's rainy here"),
              //       ),
              //       Center(
              //         child: Text("It's sunny here"),
              //       ),
              //     ],
              //   ),
              // ),),
            ],
          ),
        ),
      ),
    );
  }
}
